import { Injectable } from '@angular/core';
@Injectable()
export class Globalconstants {
    readonly baseAPIUrl: 
  //string = 'http://18.223.99.95/GDMS/api/';

//build//////////////////
//string = 'http://10.15.64.139/iocldms/api/';
//string = 'http://10.6.233.41/bmcdms/api/';//////
//string = 'http://localhost:50819/api/';

//  string = 'http://18.223.99.95/GDMS/api/';
// string = 'http://localhost/GDMS/api/';
  // string = 'https://dms.conceptlab.in/gdms/api/';
//
//string = 'https://conceptdms.in/gdms/api/';
//string = 'https://conceptdms.in/gdms/api/';
//
// string = 'https://e-storage.crownims.com/SODDMS/api/';////////
//string = 'https://e-storage.crownims.com/EDMS/api/';//
//string = 'http://192.168.0.155/EDMS/api/';
//string = 'https://annapurana.crownims.com/annapuranaDMS/api/';

 string = 'https://DMSTest.crownims.com/DMSTestDMS/api/';
//
//string = 'http://172.25.1.170/Nayaradms/api/';

// string = 'https://e-storage.crownims.com/Demotesting/api/';////

//string = 'https://SATGroup.crownims.com/SATDMS/api/';//

//string = 'http://192.168.0.155/EDMS/api/';// GaneshGrainDMS
//string = 'https://emamiagro.crownims.com/emamiagroDMS/api/';
//string = 'http://192.168.0.155/EDMS/api/';// GaneshGrainDMS
//string = 'http://10.6.233.41/DMS/api/';

//string = 'https://e-storage.crownims.com/SIFYDMS/api/';////////
 //string = 'https://SIFY.crownims.com/SIFYDMS/api/';////////
//string = 'https://karvycapital.crownims.com/karvycapitalDMS/api/';////////

//string = 'https://karvycapital.crownims.com/karycapitalDMS';

//string = 'https://IPL.crownims.com/IPLDMS/api/';////////

//string = 'https://rblegal.crownims.com/rblegalDMS/api/';////////
//string = 'https://e-storage.crownims.com/rblegalDMS/api/';////////

//string = https://IPL.crownims.com/IPLDMS
//string = 'https://e-storage.crownims.com/IPLDMS/api/';//
// string = 'https://ipl.crownims.com/IPLDMS/api/';
//Indian Potash Limited

//string = 'https://e-storage.crownims.com/rblegalDMS/api/';////////

}
 
