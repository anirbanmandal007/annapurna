## [1.0.0] 2019-09-20
### Initial Release

## [1.1.0] - 2020-02-27
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version

## [1.1.1] - 2020-03-04
### Update
- Remove .git, .gitignore, .editorconfig files
