import { Injectable } from '@angular/core';
@Injectable()
export class Globalconstants {
    readonly baseAPIUrl: 
  //string = 'http://18.223.99.95/GDMS/api/';

//build//////////////////
 string = 'http://localhost:50819/api/';  
//string = 'http://10.15.64.139/iocldms/api/';
//string = 'http://10.6.233.41/bmcdms/api/';

//  string = 'http://18.223.99.95/GDMS/api/';
// string = 'http://localhost/GDMS/api/';
  // string = 'https://dms.conceptlab.in/gdms/api/';
//
//string = 'https://conceptdms.in/gdms/api/';
//string = 'https://conceptdms.in/gdms/api/';
//
//string = 'https://e-storage.crownims.com/SODDMS/api/';//////////////
//string = 'https://e-storage.crownims.com/demodms/api/';
//string = 'http://192.168.0.152/EDMS/api/';

}
 
